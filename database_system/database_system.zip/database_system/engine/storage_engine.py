from typing import List, Optional, Any, Iterator
from storage.buffer import BufferPool
from storage.file_manager import FileManager
from sql_compiler.catalog import Schema
from utils.helpers import *


class StorageEngine:
    def __init__(self, buffer_pool: BufferPool, file_manager: FileManager):
        self.buffer_pool = buffer_pool
        self.file_manager = file_manager

    def create_table(self, table_name: str, schema: Schema) -> bool:
        """创建新表文件"""
        return self.file_manager.create_file(table_name)

    def insert_record(self, table_name: str, schema: Schema, values: List[Any]) -> Optional[int]:
        """插入记录"""
        # 序列化记录
        record_data = self._serialize_record(schema, values)

        # 尝试在现有页中插入
        page_count = self.file_manager.get_page_count(table_name)
        for page_id in range(page_count):
            page = self.buffer_pool.pin_page(table_name, page_id)
            if page and page.has_free_space(len(record_data)):
                record_id = page.insert_record(record_data)
                self.buffer_pool.unpin_page(table_name, page_id, True)
                if record_id is not None:
                    return (page_id << 16) | record_id  # 组合页ID和记录ID

        # 需要分配新页
        new_page = self.buffer_pool.allocate_page(table_name)
        if new_page:
            record_id = new_page.insert_record(record_data)
            self.buffer_pool.unpin_page(table_name, new_page.page_id, True)
            if record_id is not None:
                return (new_page.page_id << 16) | record_id

        return None

    def scan_records(self, table_name: str, schema: Schema) -> Iterator[List[Any]]:
        """扫描所有记录"""
        page_count = self.file_manager.get_page_count(table_name)
        record_size = self._calculate_record_size(schema)

        for page_id in range(page_count):
            page = self.buffer_pool.pin_page(table_name, page_id)
            if page:
                for record_id in range(page.num_records):
                    record_data = page.get_record(record_id, record_size)
                    if record_data:
                        record = self._deserialize_record(schema, record_data)
                        yield record
                self.buffer_pool.unpin_page(table_name, page_id, False)

    def _serialize_record(self, schema: Schema, values: List[Any]) -> bytes:
        """序列化记录"""
        record_data = bytearray()

        for value, col_def in zip(values, schema.columns):
            if value is None:
                # 处理NULL值
                record_data.extend(b'\x00' * get_type_size(col_def['type'], col_def.get('length', 0)))
            elif col_def['type'] == 'INT':
                record_data.extend(serialize_int(value))
            elif col_def['type'] == 'VARCHAR':
                record_data.extend(serialize_string(value, col_def.get('length', 255)))

        return bytes(record_data)

    def _deserialize_record(self, schema: Schema, record_data: bytes) -> List[Any]:
        """反序列化记录"""
        record = []
        offset = 0

        for col_def in schema.columns:
            col_type = col_def['type']
            col_length = col_def.get('length', 0)
            size = get_type_size(col_type, col_length)

            if col_type == 'INT':
                value = deserialize_int(record_data[offset:offset + size])
            elif col_type == 'VARCHAR':
                value = deserialize_string(record_data[offset:offset + size])
            else:
                value = None

            record.append(value)
            offset += size

        return record

    def _calculate_record_size(self, schema: Schema) -> int:
        """计算记录大小"""
        size = 0
        for col_def in schema.columns:
            size += get_type_size(col_def['type'], col_def.get('length', 0))
        return size
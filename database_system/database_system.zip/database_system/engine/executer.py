from typing import List, Any, Iterator
from sql_compiler.planner import QueryPlan
from .storage_engine import StorageEngine
from sql_compiler.catalog import Schema


class Executor:
    def __init__(self, storage_engine: StorageEngine):
        self.storage_engine = storage_engine

    def execute(self, plan: QueryPlan) -> Any:
        if plan.plan_type == 'SELECT':
            return self._execute_select(plan)
        elif plan.plan_type == 'INSERT':
            return self._execute_insert(plan)
        elif plan.plan_type == 'CREATE_TABLE':
            return self._execute_create_table(plan)
        else:
            raise ValueError(f"Unsupported plan type: {plan.plan_type}")

    def _execute_select(self, plan: QueryPlan) -> List[List[Any]]:
        table_name = plan.details['table_name']
        columns = plan.details['columns']
        where_clause = plan.details['where_clause']
        schema = plan.details['schema']

        results = []
        for record in self.storage_engine.scan_records(table_name, schema):
            # 应用WHERE过滤
            if where_clause and not self._evaluate_condition(where_clause, record, schema):
                continue

            # 选择指定列
            if columns == ['*']:
                results.append(record)
            else:
                selected_record = []
                for col_name in columns:
                    col_index = schema.get_column_index(col_name)
                    if col_index != -1:
                        selected_record.append(record[col_index])
                results.append(selected_record)

        return results

    def _execute_insert(self, plan: QueryPlan) -> int:
        table_name = plan.details['table_name']
        values = plan.details['values']
        schema = plan.details['schema']

        record_id = self.storage_engine.insert_record(table_name, schema, values)
        if record_id is None:
            raise Exception("Failed to insert record")

        return 1  # 返回插入的行数

    def _execute_create_table(self, plan: QueryPlan) -> bool:
        table_name = plan.details['table_name']
        columns = plan.details['columns']
        primary_key = plan.details['primary_key']

        # 创建Schema对象
        schema = Schema(table_name, columns, primary_key)

        # 创建表文件
        success = self.storage_engine.create_table(table_name, schema)
        return success

    def _evaluate_condition(self, condition, record: List[Any], schema: Schema) -> bool:
        """评估WHERE条件"""
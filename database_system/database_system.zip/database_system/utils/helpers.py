import struct
from .constants import *

def serialize_int(value):
    """序列化整型数据"""
    return struct.pack('>i', value)

def deserialize_int(data):
    """反序列化整型数据"""
    return struct.unpack('>i', data)[0]

def serialize_string(value, max_length):
    """序列化字符串数据"""
    encoded = value.encode('utf-8')
    if len(encoded) > max_length:
        encoded = encoded[:max_length]
    return encoded.ljust(max_length, b'\x00')

def deserialize_string(data):
    """反序列化字符串数据"""
    return data.decode('utf-8').rstrip('\x00')

def serialize_bool(value):
    """序列化布尔值"""
    return b'\x01' if value else b'\x00'

def deserialize_bool(data):
    """反序列化布尔值"""
    return data != b'\x00'

def get_type_size(data_type, length=0):
    """获取数据类型的大小"""
    if data_type == INT_TYPE:
        return 4
    elif data_type == FLOAT_TYPE:
        return 8
    elif data_type == BOOL_TYPE:
        return 1
    elif data_type == STRING_TYPE:
        return length
    return 0